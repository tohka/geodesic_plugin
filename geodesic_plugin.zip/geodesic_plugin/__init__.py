def classFactory(iface):
    from .geodesic_plugin import GeodesicPlugin
    return GeodesicPlugin()

